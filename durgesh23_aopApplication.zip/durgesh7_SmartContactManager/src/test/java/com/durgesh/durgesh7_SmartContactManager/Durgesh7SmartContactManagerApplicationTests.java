package com.durgesh.durgesh7_SmartContactManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh7SmartContactManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
