package com.springanotation.annotation;

import org.springframework.stereotype.Component;

@Component
public class Emp {

    public void whatsYourName(){
        System.out.println("my name is vedant");
    }

}
