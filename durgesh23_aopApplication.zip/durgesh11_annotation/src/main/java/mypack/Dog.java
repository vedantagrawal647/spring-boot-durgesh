package mypack;

import org.springframework.stereotype.Component;

@Component
public class Dog {

       public  void eating(){
           System.out.println("Pratush is bhaj");
       }



}
