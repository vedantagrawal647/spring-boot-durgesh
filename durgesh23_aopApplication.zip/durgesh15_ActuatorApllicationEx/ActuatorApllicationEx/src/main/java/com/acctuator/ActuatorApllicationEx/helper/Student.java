package com.acctuator.ActuatorApllicationEx.helper;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

@Component
public class Student {

    public  Student(){
        System.out.println("Creating the object of student");
    }

}
