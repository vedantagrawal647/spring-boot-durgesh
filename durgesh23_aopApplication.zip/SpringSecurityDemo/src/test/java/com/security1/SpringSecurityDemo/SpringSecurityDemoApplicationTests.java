package com.security1.SpringSecurityDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
