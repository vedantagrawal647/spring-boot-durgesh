package com.thirdpartyapi.webclientcallapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebclientcallapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
