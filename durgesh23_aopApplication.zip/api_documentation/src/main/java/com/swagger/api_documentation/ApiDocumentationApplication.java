package com.swagger.api_documentation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDocumentationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiDocumentationApplication.class, args);
	}

}
