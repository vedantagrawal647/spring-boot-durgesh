package com.sessionmanagement.SessionUsingRedis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionUsingRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
