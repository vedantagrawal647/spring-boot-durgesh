package com.durgesh.durgesh6_CssJsImageThymLeaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh6CssJsImageThymLeafApplicationTests {

	@Test
	void contextLoads() {
	}

}
