package com.durgesh.durgesh6_CssJsImageThymLeaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Durgesh6CssJsImageThymLeafApplication {

	public static void main(String[] args) {
		SpringApplication.run(Durgesh6CssJsImageThymLeafApplication.class, args);
	}

}
