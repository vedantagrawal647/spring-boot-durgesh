package com.durgesh.durgeag13_Lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgeag13LombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
