package com.durgesh.durgesh9_Email.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailController {




}
