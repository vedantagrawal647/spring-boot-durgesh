package com.durgesh.durgesh9_Email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh9EmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
