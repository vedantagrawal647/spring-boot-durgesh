package com.durgesh.durgesh4_thymleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh4ThymleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
