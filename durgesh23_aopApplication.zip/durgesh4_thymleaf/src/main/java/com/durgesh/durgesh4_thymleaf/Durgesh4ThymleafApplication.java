package com.durgesh.durgesh4_thymleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Durgesh4ThymleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(Durgesh4ThymleafApplication.class, args);
	}

}
