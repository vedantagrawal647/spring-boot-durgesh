package com.example.durgesh5_ServerSideFormValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh5ServerSideFormValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
