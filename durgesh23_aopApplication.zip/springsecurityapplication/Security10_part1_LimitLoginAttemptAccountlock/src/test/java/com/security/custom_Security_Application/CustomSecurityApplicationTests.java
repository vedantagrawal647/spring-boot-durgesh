package com.security.custom_Security_Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
