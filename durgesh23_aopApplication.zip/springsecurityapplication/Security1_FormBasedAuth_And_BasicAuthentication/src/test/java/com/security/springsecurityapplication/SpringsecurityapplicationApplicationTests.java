package com.security.springsecurityapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
