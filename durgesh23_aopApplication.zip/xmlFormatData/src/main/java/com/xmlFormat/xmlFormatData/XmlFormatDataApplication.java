package com.xmlFormat.xmlFormatData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlFormatDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlFormatDataApplication.class, args);
	}

}
