package com.durgesh.durgesh3_BookRestAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Durgesh3BookRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Durgesh3BookRestApiApplication.class, args);
	}

}
