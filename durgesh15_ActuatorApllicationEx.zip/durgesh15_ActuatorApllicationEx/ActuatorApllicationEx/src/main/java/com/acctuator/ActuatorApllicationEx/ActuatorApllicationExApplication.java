package com.acctuator.ActuatorApllicationEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActuatorApllicationExApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActuatorApllicationExApplication.class, args);
	}

}
