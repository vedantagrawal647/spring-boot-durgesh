package com.durgesh.durgesh9_Email;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Durgesh9EmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(Durgesh9EmailApplication.class, args);
	}

}
