package com.swagger.api_documentation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDocumentationApplicationTests {

	@Test
	void contextLoads() {
	}

}
