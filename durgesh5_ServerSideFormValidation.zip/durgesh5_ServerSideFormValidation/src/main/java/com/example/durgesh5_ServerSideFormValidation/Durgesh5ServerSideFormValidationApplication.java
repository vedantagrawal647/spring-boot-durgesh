package com.example.durgesh5_ServerSideFormValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Durgesh5ServerSideFormValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(Durgesh5ServerSideFormValidationApplication.class, args);
	}

}
