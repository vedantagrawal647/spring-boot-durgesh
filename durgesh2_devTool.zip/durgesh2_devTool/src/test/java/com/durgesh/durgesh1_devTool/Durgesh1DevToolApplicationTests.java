package com.durgesh.durgesh1_devTool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh1DevToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
