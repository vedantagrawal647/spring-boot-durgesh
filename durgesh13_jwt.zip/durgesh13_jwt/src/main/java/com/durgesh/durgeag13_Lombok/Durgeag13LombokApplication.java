package com.durgesh.durgeag13_Lombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Durgeag13LombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(Durgeag13LombokApplication.class, args);
	}

}
