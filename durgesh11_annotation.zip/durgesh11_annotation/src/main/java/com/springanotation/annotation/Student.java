package com.springanotation.annotation;

public class Student {

    public void studying(){
        System.out.println("I am studying");
    }

}
