package com.durgesh.durgesh1_Jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh1JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
