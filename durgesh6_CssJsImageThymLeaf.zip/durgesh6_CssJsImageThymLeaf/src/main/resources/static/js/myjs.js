console.log("this is a message on console");
alert("js is activated");