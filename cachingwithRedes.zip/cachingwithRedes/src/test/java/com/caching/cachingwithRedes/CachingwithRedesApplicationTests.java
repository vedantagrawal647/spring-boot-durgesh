package com.caching.cachingwithRedes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CachingwithRedesApplicationTests {

	@Test
	void contextLoads() {
	}

}
