package com.example.custom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomApplicationTests {

	@Test
	void contextLoads() {
	}

}
