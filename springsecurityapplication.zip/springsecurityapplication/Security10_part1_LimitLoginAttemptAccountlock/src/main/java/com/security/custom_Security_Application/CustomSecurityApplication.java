package com.security.custom_Security_Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class  CustomSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomSecurityApplication.class, args);
	}

}
