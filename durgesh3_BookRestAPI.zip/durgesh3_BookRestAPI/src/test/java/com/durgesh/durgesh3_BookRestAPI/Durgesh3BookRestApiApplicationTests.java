package com.durgesh.durgesh3_BookRestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Durgesh3BookRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
