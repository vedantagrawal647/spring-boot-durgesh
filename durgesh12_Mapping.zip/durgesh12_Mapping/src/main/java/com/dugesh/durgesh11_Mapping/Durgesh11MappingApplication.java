package com.dugesh.durgesh11_Mapping;


import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.security.Principal;

@SpringBootApplication
public class Durgesh11MappingApplication {



	public static void main(String[] args) {
		SpringApplication.run(Durgesh11MappingApplication.class, args);
	}


}
